/* include/config.h.  Generated from config.h.in by configure.  */
/* include/config.h.in.  Generated from configure.ac by autoheader.  */

/* Support for Linux conntrack */
#define HAVE_CONNTRACK 1

/* GeoIP support is present */
#define HAVE_GEOIP 1

/* Define to 1 if you have the <GeoIP.h> header file. */
#define HAVE_GEOIP_H 1

/* GeoIP not supported: library too old, please upgrade first */
#define HAVE_GEOIP_IPv6 1

/* Local hiredis package present */
#define HAVE_HIREDIS 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* LDAP support is present */
#define HAVE_LDAP 1

/* Support for privilege drop */
#define HAVE_LIBCAP 1

/* Define to 1 if you have the `GeoIP' library (-lGeoIP). */
#define HAVE_LIBGEOIP 1

/* Define to 1 if you have the `netfilter_queue' library (-lnetfilter_queue).
   */
#define HAVE_LIBNETFILTER_QUEUE 1

/* Define to 1 if you have the <libnetfilter_queue/libnetfilter_queue.h>
   header file. */
#define HAVE_LIBNETFILTER_QUEUE_LIBNETFILTER_QUEUE_H 1

/* Define to 1 if you have the `nfnetlink' library (-lnfnetlink). */
#define HAVE_LIBNFNETLINK 1

/* Define to 1 if you have the `wrap' library (-lwrap). */
#define HAVE_LIBWRAP 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* use mysql */
#define HAVE_MYSQL 1

/* nDB support is present */
/* #undef HAVE_NDB */

/* nedge support is present */
/* #undef HAVE_NEDGE */

/* NFQ is present */
#define HAVE_NETFILTER 1

/* Define to 1 if you have the <netinet/in.h> header file. */
#define HAVE_NETINET_IN_H 1

/* Define if nfq_set_verdict2 exists in netfilter_queue. */
#define HAVE_NFQ_SET_VERDICT2 1

/* old nedge support is present */
/* #undef HAVE_OLD_NEDGE */

/* Native PF_RING support */
/* #undef HAVE_PF_RING */

/* We have sqlite */
#define HAVE_SQLITE 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* zlib is present */
#define HAVE_ZLIB 1

/* has openssl */
#define NO_SSL_DL 1

/* Last GIT change */
#define NTOPNG_GIT_DATE "20180201"

/* GIT Release */
#define NTOPNG_GIT_RELEASE "dev:691a50922291992d5f967b8894a26b1cfd826e57:20180201"

/* Building ntopng professional */
/* #undef NTOPNG_PRO */

/* ntopng professional date */
/* #undef NTOPNG_PRO_GIT_DATE */

/* ntopng professional release */
/* #undef NTOPNG_PRO_GIT_RELEASE */

/* ntopng has license */
/* #undef NTOPNG_PRO_HAVE_LICENSE */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Architecture of this host */
#define PACKAGE_MACHINE "armv7l"

/* Define to the full name of this package. */
#define PACKAGE_NAME "ntopng"

/* OS Name */
#define PACKAGE_OS "Raspbian GNU/Linux 9.3 (stretch)"

/* OS name */
#define PACKAGE_OSNAME "Debian 9.3"

/* GIT release of this package */
#define PACKAGE_RELEASE "r691a50922291992d5f967b8894a26b1cfd826e57:20180201"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "ntopng 3.3.180201"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "ntopng"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "3.3.180201"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Disable warning on windows */
#define _CRT_SECURE_NO_WARNINGS 1
